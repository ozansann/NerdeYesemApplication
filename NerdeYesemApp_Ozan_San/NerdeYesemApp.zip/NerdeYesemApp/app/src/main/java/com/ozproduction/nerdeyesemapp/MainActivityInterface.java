package com.ozproduction.nerdeyesemapp;

public interface MainActivityInterface {
    public void SetRestaurantList(Restaurant[] restaurantList);
    public void CloseLoadingDialog();
    public void RestaurantNotFound();
}
