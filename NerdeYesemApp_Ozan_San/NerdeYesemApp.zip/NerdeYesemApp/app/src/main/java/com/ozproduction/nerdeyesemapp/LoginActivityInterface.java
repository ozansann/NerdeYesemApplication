package com.ozproduction.nerdeyesemapp;

public interface LoginActivityInterface {
    public void LoginSuccessful();
}
